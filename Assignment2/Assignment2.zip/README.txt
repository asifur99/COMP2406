"Whatever you lose, you'll find it again. But what you throw away you'll never get back." - from all CS students without days of sleep

NAME: Asifur Rahman
ID: 101069183

All you need to do is start the server.js using node and with the power of the wizards of NodeJs it'll fire up all the necessary files.
All you have to do is type node server.js in shell or wherever and everything will be in front of you!

Default webpage is Homepage.html as I made a homepage seperate which has a href link to other html pages allowing you to navigate the world of
oz. stats.rjs is kept in a seperate forlder called stats.

Thank you for the feedback really appreciated. Have a goodnight and sleep tight!