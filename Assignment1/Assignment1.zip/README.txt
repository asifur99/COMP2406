 "Let me ask you. Does a person such as yourself experience fear?"

NAME: Asifur Rahman
ID: 101069183

I have seperated the file i wrote the js in which has all the functions and stuff. Name of the file "precious.js". I have linked it in the HTML
so you dont have kill your brain cells looking at a huge file though the js file is just a mess.

All you have to do is run the order.html file to see the magic cook and presented upon you. I couldn't complete the summary and some small parts
due to lack of time and brain cells. I hope you like my coding ways and the content cause I would really love to find a new approach to this 
assignment.

Hope you all the best and PLEASE show some consideration for the fellow comrade in arms in this tournament of coding.

PS: TBH I really didn't know what to write in the readme so thought of some weird way to put it in. if you like it bonus marks please, otherwise
    a feedback would be really appreciated regardig this type of appraoch.